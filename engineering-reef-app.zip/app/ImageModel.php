<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ImageModel extends Model
{
    public $table="image_model";
    public $timestamps =false;
}
