<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Collection;

class Entry extends Model
{
    public $table="entries";
    public $timestamps =false;

}