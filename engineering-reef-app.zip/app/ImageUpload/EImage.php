<?php
/**
 * Created by PhpStorm.
 * User: voila1
 * Date: 2/4/2019
 * Time: 4:24 PM
 */

namespace App\Manager\ImageUpload;


class EImage
{
    const tableName="images";
    const id = "id";
    const image_path = "image_path";
    const user_id = "user_id";
    const is_active = "is_active";
}


