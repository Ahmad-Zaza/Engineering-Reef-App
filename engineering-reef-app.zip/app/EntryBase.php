<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Collection;

class EntryBase extends Model
{
    public $table="entry_base";
    public $timestamps =false;

}