<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InfoPages extends Model
{
    //
    public $table="info_pages";
    public $timestamps =false;
    
}
