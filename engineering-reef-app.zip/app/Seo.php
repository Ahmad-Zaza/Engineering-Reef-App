<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Seo extends Model
{
    public $table="seo";
}
